// Gefuehrte Tour (F20): hebt das jeweilige Bedienelement hervor, laesst sich ueberspringen und wiederholen.
import { h, clear } from './dom.js';
import { TOUR } from '../content/help.js';

export function createTour(app, { layer, go }) {
  let step = 0; let active = false; let onResize = null;
  const frames = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  const finish = (done) => {
    active = false; clear(layer); layer.classList.remove('open');
    if (onResize) { window.removeEventListener('resize', onResize); window.removeEventListener('orientationchange', onResize); onResize = null; }
    if (done !== undefined) app.setPrefs({ tourDone: true });
  };

  async function show(i) {
    step = i;
    const s = TOUR[i];
    go(s.route);
    await frames();
    if (!active) return;
    const el = document.querySelector(s.sel) || (s.fallback && document.querySelector(s.fallback));
    if (el) el.scrollIntoView({ block: 'center', inline: 'nearest' });
    await frames();
    draw(s, el);
    onResize = () => { const e2 = document.querySelector(s.sel) || (s.fallback && document.querySelector(s.fallback)); draw(s, e2); };
    window.addEventListener('resize', onResize); window.addEventListener('orientationchange', onResize);
  }

  function draw(s, el) {
    clear(layer);
    const last = step === TOUR.length - 1;
    const card = h('div', { class: 'tour-card', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Tour', 'data-testid': 'tour-karte' },
      h('div', { class: 'tour-step', 'data-testid': 'tour-schritt' }, `Schritt ${step + 1} von ${TOUR.length}`),
      h('h3', { 'data-testid': 'tour-titel' }, s.titel),
      h('p', {}, s.text),
      h('div', { class: 'row between' },
        h('button', { class: 'btn quiet', 'data-testid': 'tour-ueberspringen', onclick: () => finish(true) }, 'Überspringen'),
        h('div', { class: 'row' },
          step > 0 ? h('button', { class: 'btn', 'data-testid': 'tour-zurueck', onclick: () => show(step - 1) }, 'Zurück') : null,
          h('button', { class: 'btn primary', 'data-testid': 'tour-weiter', onclick: () => (last ? (finish(true), go('#/plan')) : show(step + 1)) }, last ? 'Fertig' : 'Weiter'))));
    const hole = h('div', { class: 'tour-hole', 'data-testid': 'tour-markierung' });
    layer.append(hole, card);
    layer.classList.add('open');
    const vh = window.innerHeight; const vw = window.innerWidth;
    if (el) {
      const r = el.getBoundingClientRect();
      const pad = 6;
      Object.assign(hole.style, { top: `${r.top - pad}px`, left: `${r.left - pad}px`, width: `${r.width + 2 * pad}px`, height: `${r.height + 2 * pad}px` });
      hole.dataset.ziel = s.sel;
      const cardH = card.offsetHeight || 190;
      const below = vh - r.bottom;
      card.style.top = below > cardH + 24 ? `${r.bottom + pad + 12}px` : `${Math.max(12, r.top - cardH - pad - 12)}px`;
    } else {
      hole.style.display = 'none';
      card.style.top = `${Math.max(12, (vh - 200) / 2)}px`;
    }
    card.style.left = '50%'; card.style.transform = 'translateX(-50%)'; card.style.width = `${Math.min(440, vw - 24)}px`;
  }

  function offer() {
    clear(layer); layer.classList.add('open');
    layer.append(h('div', { class: 'tour-card center', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Tour anbieten', 'data-testid': 'tour-angebot' },
      h('h3', {}, 'Kurze Tour?'),
      h('p', {}, 'In etwa einer Minute zeige ich dir, wie du einen Plan machst und den Einkaufszettel weitergibst. Du kannst sie später in der Hilfe wiederholen.'),
      h('div', { class: 'row between' },
        h('button', { class: 'btn quiet', 'data-testid': 'tour-spaeter', onclick: () => finish(true) }, 'Später'),
        h('button', { class: 'btn primary', 'data-testid': 'tour-starten', onclick: () => { clear(layer); active = true; show(0); } }, 'Tour starten'))));
  }

  return {
    start({ angebot = false } = {}) { if (active) finish(); if (angebot) { active = false; offer(); } else { active = true; show(0); } },
    isActive: () => active,
  };
}
