# Kochplaner – Projektstand
Wiederaufnahme: zuerst `START_HIER.md` lesen (Anleitung für jede Claude-Instanz). Danach Begleitdokument im Drive-Ordner "Kochplaner" (Google Sheet "Kochplaner – Fortschritt (Begleitdokument)", Tabs Meilensteine, Fortsetzen, Log).
Zieldokument: https://claude.ai/artifact/4ZU4vdJjGJihECm1Ngroft (Kopie: docs/ZIELDOKUMENT.md)
Stand: M0, M1, M2, M3, M4 fertig (15.11.2026). Als Nächstes M5: Playwright-Szenarien F01–F23 (tests/e2e/), iPhone/iPad, 3 Profile, Zweitgerät, Fehlerfälle, Videos/Screenshots.
Tests (alle grün): `./data/build_all.sh` (21 Oracle-Selbsttests), `node --test "tests/unit/**/*.test.mjs"` (154), `node --test "tests/contract/**/*.test.mjs"` (89), `node tests/tools/export_shuffle_runs.mjs && python3 oracle/check_shuffle.py`. Alles zusammen: `npm run test:all`.
Echtes Sheet (nur lesend, erst nach Einrichtung): `KP_URL=... KP_TOKEN=... node tests/contract/live.mjs`.
Mutationsprüfung Code.gs (20 Mutanten, alle gefunden): `bash tests/tools/mutate_gs.sh` (dauert ca. 10 Minuten, im Hintergrund starten).
Entscheidungen: docs/DECISIONS.md (D01–D48). Protokoll: docs/PROTOCOL.md.
Schnittstelle: backend/Code.gs (Apps Script), backend/mock_server.py (Mock), tests/tools/gs_sim.mjs (Simulator), app/js/adapters/api.js (Client).
App starten (lokal, mit Mock): `python3 backend/mock_server.py --xlsx data/kochplaner_test.xlsx --app app --token <mind. 16 Zeichen> --port 0` (gibt `PORT=…` aus). Setup-Code für Tests: `KP1.`+base64url(JSON{u:"http://127.0.0.1:PORT/exec",t:TOKEN}).
App-Quelle: app/ (statisch, ohne Build): index.html, js/state.js (Zustand), js/main.js (Routen), js/ui/views/*, js/core/* (reine Logik), css/app.css, sw.js.
Testschalter nur über window.__kpTest (siehe D44). Hilfe-/Import-Text: app/js/content/*; docs/IMPORT_ANLEITUNG.md erzeugen mit `node tests/tools/export_import_prompt.mjs`.
Bekannte offene Punkte: F14 Meal-Prep nicht umgesetzt (Kann, D48); E2E-Szenarien noch nicht als feste Dateien (nur Rauchtests in /tmp, werden in M5 zu tests/e2e/).
