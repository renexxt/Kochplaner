# Mutationspruefung der Web-App

| Fehler | Was falsch ist | Unit-Tests | E2E-Tests | Erster E2E-Befund |
|---|---|---|---|---|
| A (Pflicht) | Skalierung ohne Division durch die Basisportionen (Mengen stimmen nur bei Basisportion) | gefunden | gefunden | test_f01_f05_plan.py::test_f05_portionen_hin_und_zurueck E           AssertionError: F05: Einkaufszettel bei 5 Portionen entspricht dem Orakel |
| B (Pflicht) | Abgehakte Eintraege gehen beim Neuladen verloren | gefunden | gefunden | test_f06_f10_einkauf.py::test_f07_abhaken_persistent_und_zuruecksetzen E           AssertionError: F07: Haken bleiben nach dem Neuladen erhalten |
| C (Pflicht) | Startdatum um einen Tag verschoben (Woche beginnt einen Tag zu spaet) | gefunden | gefunden | test_f01_f05_plan.py::test_f01_startdatum_profile[anna-2026-11-18] E           playwright._impl._errors.TimeoutError: Page.wait_for_function: Timeout 30000ms exceeded. |
| D | Fixierte Tage werden beim 'Alle neu wuerfeln' trotzdem ueberschrieben | gefunden | gefunden | test_f01_f05_plan.py::test_f03_tag_aendern_fixieren E           AssertionError: F03: fixierter Tag bleibt bei 'Alle neu wuerfeln' |
| E | Stueck wird nach dem Addieren abgerundet statt auf 0,5 aufgerundet | gefunden | gefunden | test_f01_f05_plan.py::test_f05_portionen_hin_und_zurueck E           AssertionError: F05: Einkaufszettel bei 5 Portionen entspricht dem Orakel |
| F | Kalorien gesamt rechnen immer mit 2 Portionen | nicht gefunden | gefunden | test_f01_f05_plan.py::test_f04_tagesansicht_gegen_orakel[anna] E           AssertionError: F04: kcal gesamt = kcal/Portion x Portionen: 860 kcal gesamt (Orakel 430) |
| G | Verspaetete Leseantwort ueberschreibt den frisch gespeicherten Plan (B2) | gefunden | nicht gefunden |   |
| H | Erneutes Verbinden mit gleicher Adresse verwirft ungespeicherten Plan und offene Bewertungen (B3) | gefunden | gefunden | test_review_fixes.py::test_b3_neu_verbinden_behaelt_ungespeicherten_plan E           AssertionError: F16: Plan wurde nach dem Verbinden gespeichert |
| I | Text im Schnellfeld geht beim Speichern verloren (B4) | nicht gefunden | gefunden | test_review_fixes.py::test_b4_text_im_schnellfeld_wird_beim_speichern_uebernommen E           AssertionError: F12: alle drei Zutaten aus dem Schnellfeld gespeichert |
| J | Neues Gericht ohne Anfrage-Kennung: nach verlorener Antwort entsteht ein Doppel (B8) | nicht gefunden | gefunden | test_review_fixes.py::test_b8_verlorene_antwort_legt_kein_doppel_an E           AssertionError: F16: nach dem zweiten Versuch immer noch genau ein Gericht |
| K | Entwurf bleibt nach erfolgreichem Speichern erhalten (B5) | nicht gefunden | gefunden | test_review_fixes.py::test_b5_entwurf_bleibt_bei_tabwechsel_und_neuladen E           AssertionError: F11: nach erfolgreichem Speichern beginnt das Formular leer |
| L | Einkaufszettel verschluckt Rechenfehler ohne Meldung (B15) | gefunden | nicht gefunden |   |
| M | 1.500 g Mehl wird still als 1,5 g gelesen statt als unklar markiert (B14) | gefunden | gefunden | test_review_fixes.py::test_b4_unklare_zeile_haelt_das_speichern_an E           playwright._impl._errors.TimeoutError: Page.wait_for_selector: Timeout 30000ms exceeded. |
| N | Notizfeld verliert beim Neuaufbau der Liste den Fokus (B9) | nicht gefunden | gefunden | test_review_fixes.py::test_b9_fokus_im_notizfeld_bleibt_bei_aktualisierung E           AssertionError: F22: Fokus und Text im Notizfeld bleiben erhalten |
| O | Haken bleibt stehen, obwohl sich die Menge des Eintrags geaendert hat (F07: nie zu wenig kaufen) | gefunden | gefunden | test_f06_f10_einkauf.py::test_f07_haken_nur_bei_unveraenderter_menge E           AssertionError: F07: Eintraege mit geaenderter Menge sind wieder offen (nie zu wenig kaufen) |
