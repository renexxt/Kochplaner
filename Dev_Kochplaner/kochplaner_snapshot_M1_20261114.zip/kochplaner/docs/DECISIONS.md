# DECISIONS.md – Annahmen und Begründungen

Wird in jedem Meilenstein ergänzt. Festlegungen, die im Zieldokument offen waren, stehen hier mit Begründung.

## M1 – Daten und Orakel

| Nr. | Festlegung | Begründung |
|---|---|---|
| D01 | Leere Zelle: `favorit` und `nie_wieder` = nein, `aktiv` = ja, `einkaufen` = ja, `status` = fertig, `reicht_fuer_tage` = 1. | Entspricht den Standardwerten im Datenmodell; ein vom Chat-Import weggelassenes Feld soll nichts sperren. |
| D02 | `ja`/`nein` wird ohne Groß-/Kleinschreibung gelesen; auch `j`, `x`, `true`, `wahr`, `1` bzw. `n`, `false`, `falsch`, `0`. | „ja/nein in beliebiger Schreibweise“ im Datenmodell. |
| D03 | Zahlen werden als Zahl, als Text mit Komma oder Punkt, als Bruch (`1/2`, `1 1/2`) und mit Sonderzeichen (`½`, `1½`) gelesen. Ein Punkt gilt immer als Dezimalpunkt (`1.000` = 1). | Das Sheet wird teils von Hand, teils vom Chat-Import gefüllt. Tausenderpunkte kommen bei Kochmengen nicht vor. |
| D04 | `kcal_pro_portion` ≤ 0 oder nicht lesbar zählt als leer („kcal fehlt“). | „nie 0“ im Datenmodell. |
| D05 | Einheiten werden ohne Groß-/Kleinschreibung und Schlusspunkt erkannt (`ML`, `el`, `Stk.`, `Gramm`, `Liter`, `Dosen` …) und auf g, kg, ml, l, EL, TL, Stück, Dose, Bund, Packung, Prise vereinheitlicht. Unbekannte Einheiten bleiben stehen und werden nur mit gleicher Schreibweise addiert. | Toleranz beim Lesen, normalisiertes Schreiben. |
| D06 | Gleiche Zutat = gleicher Name ohne Groß-/Kleinschreibung, mit gekürzten und zusammengefassten Leerzeichen. Anzeigename = erste Schreibweise im Plan, erster Buchstabe groß. | Aus F06 („ohne Groß-/Kleinschreibung und Leerzeichen“). |
| D07 | Zutaten ohne Menge erscheinen einmal nur mit Namen. Kommt dieselbe Zutat auch mit Menge vor, geht die Zeile ohne Menge darin auf (z. B. „Salz“ ohne Menge plus „1 TL Salz“ ergibt „1 TL Salz“). | Eine Liste mit „Salz“ und „1 TL Salz“ wäre doppelt. Zieldokument sagt nur „skalieren nicht“. |
| D08 | Zeilenformat des Einkaufszettels: `<Menge> <Einheit> <Name>`, die Einheit „Stück“ bleibt sichtbar („4 Stück Eier“), ohne Menge nur der Name. | „1,5 l Milch“ im Zieldokument. Stück sichtbar lassen vermeidet Missverständnisse wie „4 Brot“. |
| D09 | Anzeige hoechstens 2 Nachkommastellen, kaufmännisch gerundet (2,625 kg → 2,63 kg), ohne Endnullen, Dezimalkomma. Aufrunden auf 0,5 gilt nur für Stück und erst nach dem Addieren. g/ml bleiben bis 1000 in g/ml, ab 1000 in kg/l. | F06. Das Zieldokument nennt die Rundung nicht. |
| D10 | Sortierung nach Name mit deutscher Sortierung (DIN 5007-1: ä = a, ö = o, ü = u, ß = ss, Groß = klein); gleiche Namen mit verschiedenen Einheiten nach Einheit. Die App nutzt dieselbe Schlüsselfunktion, nicht `localeCompare`. | Ergebnis soll auf jedem Gerät gleich sein. |
| D11 | Bewertungsgewichte (Favorit ×2, Durchschnitt ab 4 ×1,5, Durchschnitt bis 2 ×0,5) werden multipliziert. Beide Durchschnittsgewichte gelten erst ab 2 Bewertungen. Eine einzelne 5-Sterne-Bewertung ändert weder Gewicht noch Rangliste. | F23 nennt „ab 2 Bewertungen“ für die untere Schwelle; für die obere ist es nicht festgelegt, gleiche Regel ist konsistent. |
| D12 | Rangliste: nur Gerichte mit mindestens 2 Bewertungen, sortiert nach Durchschnitt, dann Anzahl, dann Name, dann id. „Beste“ = die ersten min(5, aufgerundet n/2), „Schwächste“ = die letzten min(5, abgerundet n/2) in umgekehrter Reihenfolge. | Beide Listen überschneiden sich so nie. |
| D13 | Eine Bewertung ist eindeutig durch (Gericht, Datum, von). Erneutes Bewerten desselben Tages durch dieselbe Person überschreibt, zwei Personen am selben Tag ergeben zwei Bewertungen. | F22 „überschreibt“; zwei Haushaltsmitglieder bewerten unabhängig. |
| D14 | Tauschen und Suche zeigen alle aktiven, fertigen Gerichte, auch solche mit `nie_wieder`. Nur der Shuffle schließt `nie_wieder` aus. | F02 und F03 im Zieldokument. |
| D15 | Testdaten: Stückzutaten kommen natürlich in vielen Gerichten vor (Zwiebel, Eier, Paprika), nicht nur in dreien. Die Vorgabe „3 Gerichte“ gilt als Mindestzahl. Ohne kcal sind 2 fertige Gerichte (G008, G023), dazu die Idee G040. | Natürlichere Daten, strengerer Test. |
| D16 | Eine einzelne 5-Sterne-Bewertung (G011) prüft D11. | Testet die „ab 2 Bewertungen“-Regel in beide Richtungen. |
| D17 | Ein Punkt in einem Datum wird als Format TT.MM.JJJJ gelesen, `JJJJ-MM-TT` als ISO. Die Schnittstelle liefert Datumszellen immer als `JJJJ-MM-TT` (Zeitzone Europe/Berlin). | Vermeidet Zeitzonen-Verschiebung bei Apps-Script-Datumsobjekten. |
