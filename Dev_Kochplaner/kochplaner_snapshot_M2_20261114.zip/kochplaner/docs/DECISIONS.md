# DECISIONS.md – Annahmen und Begründungen

Wird in jedem Meilenstein ergänzt. Festlegungen, die im Zieldokument offen waren, stehen hier mit Begründung.

## M1 – Daten und Orakel

| Nr. | Festlegung | Begründung |
|---|---|---|
| D01 | Leere Zelle: `favorit` und `nie_wieder` = nein, `aktiv` = ja, `einkaufen` = ja, `status` = fertig, `reicht_fuer_tage` = 1. | Entspricht den Standardwerten im Datenmodell; ein vom Chat-Import weggelassenes Feld soll nichts sperren. |
| D02 | `ja`/`nein` wird ohne Groß-/Kleinschreibung gelesen; auch `j`, `x`, `true`, `wahr`, `1` bzw. `n`, `false`, `falsch`, `0`. | „ja/nein in beliebiger Schreibweise“ im Datenmodell. |
| D03 | Zahlen werden als Zahl, als Text mit Komma oder Punkt, als Bruch (`1/2`, `1 1/2`) und mit Sonderzeichen (`½`, `1½`) gelesen. Ein Punkt gilt immer als Dezimalpunkt (`1.000` = 1). | Das Sheet wird teils von Hand, teils vom Chat-Import gefüllt. Tausenderpunkte kommen bei Kochmengen nicht vor. |
| D04 | `kcal_pro_portion` ≤ 0 oder nicht lesbar zählt als leer („kcal fehlt“). | „nie 0“ im Datenmodell. |
| D05 | Einheiten werden ohne Groß-/Kleinschreibung und Schlusspunkt erkannt (`ML`, `el`, `Stk.`, `Gramm`, `Liter`, `Dosen` …) und auf g, kg, ml, l, EL, TL, Stück, Dose, Bund, Packung, Prise vereinheitlicht. Unbekannte Einheiten bleiben stehen und werden nur mit gleicher Schreibweise addiert. | Toleranz beim Lesen, normalisiertes Schreiben. |
| D06 | Gleiche Zutat = gleicher Name ohne Groß-/Kleinschreibung, mit gekürzten und zusammengefassten Leerzeichen. Anzeigename = erste Schreibweise im Plan, erster Buchstabe groß. | Aus F06 („ohne Groß-/Kleinschreibung und Leerzeichen“). |
| D07 | Zutaten ohne Menge erscheinen einmal nur mit Namen. Kommt dieselbe Zutat auch mit Menge vor, geht die Zeile ohne Menge darin auf (z. B. „Salz“ ohne Menge plus „1 TL Salz“ ergibt „1 TL Salz“). | Eine Liste mit „Salz“ und „1 TL Salz“ wäre doppelt. Zieldokument sagt nur „skalieren nicht“. |
| D08 | Zeilenformat des Einkaufszettels: `<Menge> <Einheit> <Name>`, die Einheit „Stück“ bleibt sichtbar („4 Stück Eier“), ohne Menge nur der Name. | „1,5 l Milch“ im Zieldokument. Stück sichtbar lassen vermeidet Missverständnisse wie „4 Brot“. |
| D09 | Anzeige hoechstens 2 Nachkommastellen, kaufmännisch gerundet (2,625 kg → 2,63 kg), ohne Endnullen, Dezimalkomma. Aufrunden auf 0,5 gilt nur für Stück und erst nach dem Addieren. g/ml bleiben bis 1000 in g/ml, ab 1000 in kg/l. | F06. Das Zieldokument nennt die Rundung nicht. |
| D10 | Sortierung nach Name mit deutscher Sortierung (DIN 5007-1: ä = a, ö = o, ü = u, ß = ss, Groß = klein); gleiche Namen mit verschiedenen Einheiten nach Einheit. Die App nutzt dieselbe Schlüsselfunktion, nicht `localeCompare`. | Ergebnis soll auf jedem Gerät gleich sein. |
| D11 | Bewertungsgewichte (Favorit ×2, Durchschnitt ab 4 ×1,5, Durchschnitt bis 2 ×0,5) werden multipliziert. Beide Durchschnittsgewichte gelten erst ab 2 Bewertungen. Eine einzelne 5-Sterne-Bewertung ändert weder Gewicht noch Rangliste. | F23 nennt „ab 2 Bewertungen“ für die untere Schwelle; für die obere ist es nicht festgelegt, gleiche Regel ist konsistent. |
| D12 | Rangliste: nur Gerichte mit mindestens 2 Bewertungen, sortiert nach Durchschnitt, dann Anzahl, dann Name, dann id. „Beste“ = die ersten min(5, aufgerundet n/2), „Schwächste“ = die letzten min(5, abgerundet n/2) in umgekehrter Reihenfolge. | Beide Listen überschneiden sich so nie. |
| D13 | Eine Bewertung ist eindeutig durch (Gericht, Datum, von). Erneutes Bewerten desselben Tages durch dieselbe Person überschreibt, zwei Personen am selben Tag ergeben zwei Bewertungen. | F22 „überschreibt“; zwei Haushaltsmitglieder bewerten unabhängig. |
| D14 | Tauschen und Suche zeigen alle aktiven, fertigen Gerichte, auch solche mit `nie_wieder`. Nur der Shuffle schließt `nie_wieder` aus. | F02 und F03 im Zieldokument. |
| D15 | Testdaten: Stückzutaten kommen natürlich in vielen Gerichten vor (Zwiebel, Eier, Paprika), nicht nur in dreien. Die Vorgabe „3 Gerichte“ gilt als Mindestzahl. Ohne kcal sind 2 fertige Gerichte (G008, G023), dazu die Idee G040. | Natürlichere Daten, strengerer Test. |
| D16 | Eine einzelne 5-Sterne-Bewertung (G011) prüft D11. | Testet die „ab 2 Bewertungen“-Regel in beide Richtungen. |
| D17 | Ein Punkt in einem Datum wird als Format TT.MM.JJJJ gelesen, `JJJJ-MM-TT` als ISO. Die Schnittstelle liefert Datumszellen immer als `JJJJ-MM-TT` (Zeitzone Europe/Berlin). | Vermeidet Zeitzonen-Verschiebung bei Apps-Script-Datumsobjekten. |

## M2 – Kernlogik

| Nr. | Festlegung | Begründung |
|---|---|---|
| D18 | Testdaten: `nie_wieder` steht bei G014, G031, G032. Die niedrig bewerteten Gerichte G024 (Ø 2,0) und G035 (Ø 1,5) bleiben vorschlagbar. G014 (Ø ≤ 2) ist `nie_wieder` und deshalb für den Gewichtstest ungeeignet. | Sonst wäre der Test zu F23 leer: ein ausgeschlossenes Gericht kann nicht seltener vorgeschlagen werden. Basisdatei: 32 vorschlagbare Gerichte (40 − 4 inaktiv − 3 nie_wieder − 1 Idee), Anna: 36. |
| D19 | Zutaten-Schnelleingabe: „2 Eier“ ergibt Einheit Stück, der Name beginnt groß. „Prise Salz“ und „eine Prise Salz“ ergeben die Einheit Prise ohne Menge. Bereiche („2-3 Zwiebeln“) und Zeilen ohne erkennbare Menge bei Einheit am Ende („Mehl g“) werden als „unklar“ markiert und nicht geraten. „eine halbe Zitrone“ ergibt 0,5 Stück. | Der Parser ist regelbasiert (keine KI in der App). Unklares sichtbar machen statt falsch einkaufen. |
| D20 | Shuffle-Sperrfrist: Ein Gericht zählt als „kürzlich gekocht“, wenn sein Plan-Datum 1 bis `wiederholungssperre_tage` (Standard 21) Tage vor dem Starttag liegt. Der Starttag selbst und spätere Tage zählen nicht. | Der Plan der neuen Woche soll nicht mit sich selbst kollidieren. Tag −21 zählt, Tag −22 nicht (Test). |
| D21 | Auswahl in Stufen: Zuerst werden Gerichte ohne Sperrfrist gewichtet gezogen (Efraimidis-Spirakis, ohne Zurücklegen). Reichen sie nicht für alle freien Tage, springen Gerichte aus der Sperrfrist ein. Reichen auch alle vorschlagbaren Gerichte nicht für 7 Tage, werden sie in Durchgängen wiederholt und die Warnung `WENIGER_ALS_7` wird gemeldet. Jedes Gericht kommt dann mindestens einmal vor, bevor eines doppelt erscheint. | F02: nie eine Wiederholung, wenn genug Gerichte da sind; sonst trotzdem 7 Tage. |
| D22 | Fixierte Tage bleiben unverändert. Ihre Gerichte werden bei der Auswahl für die übrigen Tage ausgeschlossen. Die Portionen jedes Tages bleiben immer erhalten. | F03. |
| D23 | „Neu würfeln“ für einen Tag: neue Wahl aus Stufe 1 (frei, nicht in anderen Tagen, nicht das bisherige Gericht), sonst Stufe 2 (Sperrfrist), sonst unverändert (`geaendert: false`). Fixierte Tage werden nie neu gewürfelt. | F03; der Tag soll sich sichtbar ändern, wenn es irgendeine Alternative gibt. |
| D24 | Zufall ist ein seedbarer Generator (mulberry32). Gleicher Seed ergibt denselben Plan, unabhängig von der Reihenfolge der Gerichte im Sheet (Sortierung nach id vor dem Ziehen). In der App kommt der Seed aus der Uhrzeit, in Tests ist er fest. | Tests müssen wiederholbar sein; Nutzer sollen jedes Mal einen anderen Plan sehen. |
| D25 | Statistische Abnahme (je 1000 Läufe, fester Seed, in Python unabhängig nachgerechnet): Favoriten ≥ 1,5-mal so oft wie Nicht-Favoriten (gemessen ca. 2,4-mal), niedrig bewertete Gerichte höchstens 0,75-mal so oft wie unbewertete Nicht-Favoriten (gemessen ca. 0,54-mal) und größer als 0,3-mal, also nicht faktisch ausgeschlossen. | F02 und F23 nennen die Schwellen. Messwerte stehen in `evidence/shuffle_runs.json` und `oracle/check_shuffle.py`. |
