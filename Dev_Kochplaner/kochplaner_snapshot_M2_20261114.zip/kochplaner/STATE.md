# Kochplaner – Projektstand
Wiederaufnahme: Begleitdokument im Drive-Ordner "Kochplaner" lesen (Google Sheet "Kochplaner – Fortschritt (Begleitdokument)", Tabs Meilensteine, Fortsetzen, Log).
Zieldokument: https://claude.ai/artifact/4ZU4vdJjGJihECm1Ngroft
Stand: M0, M1, M2 fertig (14.11.2026). Als Nächstes M3: Protokoll, Mock-Server, Code.gs, Vertragstests.
Tests: `./data/build_all.sh`, `node --test "tests/unit/**/*.test.mjs"` (123 grün), `node tests/tools/export_shuffle_runs.mjs && python3 oracle/check_shuffle.py`.
Entscheidungen: docs/DECISIONS.md (D01–D25).
