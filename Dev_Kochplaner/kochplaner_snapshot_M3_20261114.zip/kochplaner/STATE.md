# Kochplaner – Projektstand
Wiederaufnahme: zuerst `START_HIER.md` lesen (Anleitung für jede Claude-Instanz). Danach Begleitdokument im Drive-Ordner "Kochplaner" (Google Sheet "Kochplaner – Fortschritt (Begleitdokument)", Tabs Meilensteine, Fortsetzen, Log).
Zieldokument: https://claude.ai/artifact/4ZU4vdJjGJihECm1Ngroft (Kopie: docs/ZIELDOKUMENT.md)
Stand: M0, M1, M2, M3 fertig (14.11.2026). Als Nächstes M4: komplette Web-App (UI, Offline, PWA).
Tests (alle grün): `./data/build_all.sh` (21 Oracle-Selbsttests), `node --test "tests/unit/**/*.test.mjs"` (123), `node --test "tests/contract/**/*.test.mjs"` (89), `node tests/tools/export_shuffle_runs.mjs && python3 oracle/check_shuffle.py`. Alles zusammen: `npm run test:all`.
Echtes Sheet (nur lesend, erst nach Einrichtung): `KP_URL=... KP_TOKEN=... node tests/contract/live.mjs`.
Mutationsprüfung Code.gs (20 Mutanten, alle gefunden): `bash tests/tools/mutate_gs.sh` (dauert ca. 10 Minuten, im Hintergrund starten).
Entscheidungen: docs/DECISIONS.md (D01–D36). Protokoll: docs/PROTOCOL.md.
Schnittstelle: backend/Code.gs (Apps Script), backend/mock_server.py (Mock), tests/tools/gs_sim.mjs (Simulator), app/js/adapters/api.js (Client).
