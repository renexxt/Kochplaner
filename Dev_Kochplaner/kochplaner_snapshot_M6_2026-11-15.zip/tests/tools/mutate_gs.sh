#!/bin/bash
# Mutationspruefung fuer Code.gs: jeder Mutant muss von den Vertragstests gefunden werden
set -u
SRC="${KP_ROOT:-$(cd "$(dirname "$0")/../.." && pwd)}"
rm -rf /tmp/mutgs && mkdir -p /tmp/mutgs
cp -r $SRC /tmp/mutgs/k
cd /tmp/mutgs/k
cp backend/Code.gs /tmp/mutgs/Code.orig
run() { node --test "tests/contract/**/*.test.mjs" 2>&1 | grep -E '^# fail' | awk '{print $3}'; }
mut() { # name, python-replace old, new
  cp /tmp/mutgs/Code.orig backend/Code.gs
  python3 - "$2" "$3" <<'PY'
import sys
p='backend/Code.gs'; s=open(p,encoding='utf-8').read(); old,new=sys.argv[1],sys.argv[2]
assert s.count(old)>=1, 'Mutationsstelle nicht gefunden: '+old
s=s.replace(old,new,1); open(p,'w',encoding='utf-8').write(s)
PY
  [ $? -ne 0 ] && { echo "$1: MUTATION NICHT ANWENDBAR"; return; }
  f=$(run); echo "$1: $f fehlgeschlagene Tests $([ "${f:-0}" -gt 0 ] && echo '-> gefunden' || echo '-> NICHT GEFUNDEN')"
}
mut "M01 Token-Pruefung aus" "if (diff !== 0) throw" "if (false) throw"
mut "M02 Datum per toISOString (Tag-Versatz)" "var d = Utilities.formatDate(v, KP.TZ, 'yyyy-MM-dd');" "var d = v.toISOString().slice(0, 10);"
mut "M03 Zeitzone UTC statt Berlin" "TZ: 'Europe/Berlin'," "TZ: 'UTC',"
mut "M04 Text nicht gegen Sheets-Umdeutung geschuetzt" "  if (typeof v !== 'string' || v === '') return v;" "  return v;"
mut "M05 Bewertung: Person im Schluessel ignoriert" "&& r.datum === datum && trim_(r.von) === von" "&& r.datum === datum"
mut "M06 Plan: Upsert haengt immer an" "var existing = rowOfDate[c.datum];" "var existing = null;"
mut "M07 neue Nummer = Anzahl+1 statt Maximum+1" "id = 'G' + ('000' + (maxNum + 1)).slice(-3);" "id = 'G' + ('000' + (tg.records.length + 1)).slice(-3);"
mut "M08 Zutaten beim Ersetzen nicht geloescht" "    deleteRows_(tz.sheet, del);" "    /* nichts */"
mut "M09 Sperre wird nicht freigegeben" "    lock.releaseLock();" "    /* offen */"
mut "M10 Portionen bis 30 erlaubt" "intIn_(r.portionen, 1, 20, f + '.portionen')" "intIn_(r.portionen, 1, 30, f + '.portionen')"
mut "M11 Sterne bis 10 erlaubt" "intIn_(req.sterne, 1, 5, 'sterne')" "intIn_(req.sterne, 1, 10, 'sterne')"
mut "M12 Tag leeren loescht nicht" "if (existing) { delRows.push(existing); geloescht++; }" "if (existing) { geloescht++; }"
mut "M13 Zeilen mit unbekanntem Gericht erlaubt" "if (gid !== '' && !known[gid]) throw" "if (false) throw"
mut "M14 kein Zeilen-Schutz beim Loeschen (aufsteigend loeschen)" "var sorted = nums.slice().sort(function (a, b) { return b - a; });" "var sorted = nums.slice().sort(function (a, b) { return a - b; });"
mut "M15 Name wird nicht normalisiert" "var name = trim_(g.name).replace(/\\s+/g, ' ');" "var name = trim_(g.name);"
mut "M16 status idee nur bei fehlender Menge" "rec.status = zutaten.length ? 'fertig' : 'idee';" "rec.status = 'fertig';"
mut "M17 Fremdspalten werden ueberschrieben" "var out = rowNum ? t.sheet.getRange(rowNum, 1, 1, t.ncols).getValues()[0] : [];" "var out = [];"
mut "M18 leere Zeilen werden mitgeliefert" "    if (empty) continue;" "    /* leer mitnehmen */"
mut "M19 Kopfzeilen nicht getrimmt" "var header = (values[0] || []).map(trim_);" "var header = (values[0] || []).map(String);"
mut "M20 Einstellung legt immer neue Zeile an" "if (trim_(r.schluessel).toLowerCase() === key) row = t.rowNums[k];" "/* nie gefunden */"
cd /; rm -rf /tmp/mutgs
