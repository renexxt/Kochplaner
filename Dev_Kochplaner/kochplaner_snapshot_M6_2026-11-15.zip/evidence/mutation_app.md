# Mutationspruefung der Web-App

| Fehler | Was falsch ist | Unit-Tests | E2E-Tests | Erster E2E-Befund |
|---|---|---|---|---|
| A (Pflicht) | Skalierung ohne Division durch die Basisportionen (Mengen stimmen nur bei Basisportion) | gefunden | gefunden | test_f01_f05_plan.py::test_f05_portionen_hin_und_zurueck E           AssertionError: F05: Einkaufszettel bei 5 Portionen entspricht dem Orakel |
| B (Pflicht) | Abgehakte Eintraege gehen beim Neuladen verloren | gefunden | gefunden | test_f06_f10_einkauf.py::test_f07_abhaken_persistent_und_zuruecksetzen E           AssertionError: F07: Haken bleiben nach dem Neuladen erhalten |
| C (Pflicht) | Startdatum um einen Tag verschoben (Woche beginnt einen Tag zu spaet) | gefunden | gefunden | test_f01_f05_plan.py::test_f01_startdatum_profile[anna-2026-11-18] E           playwright._impl._errors.TimeoutError: Page.wait_for_function: Timeout 30000ms exceeded. |
| D | Fixierte Tage werden beim 'Alle neu wuerfeln' trotzdem ueberschrieben | gefunden | gefunden | test_f01_f05_plan.py::test_f03_tag_aendern_fixieren E           AssertionError: F03: fixierter Tag bleibt bei 'Alle neu wuerfeln' |
| E | Stueck wird nach dem Addieren abgerundet statt auf 0,5 aufgerundet | gefunden | gefunden | test_f01_f05_plan.py::test_f05_portionen_hin_und_zurueck E           AssertionError: F05: Einkaufszettel bei 5 Portionen entspricht dem Orakel |
| F | Kalorien gesamt rechnen immer mit 2 Portionen | nicht gefunden | gefunden | test_f01_f05_plan.py::test_f04_tagesansicht_gegen_orakel[anna] E           AssertionError: F04: kcal gesamt = kcal/Portion x Portionen: 860 kcal gesamt (Orakel 430) |
